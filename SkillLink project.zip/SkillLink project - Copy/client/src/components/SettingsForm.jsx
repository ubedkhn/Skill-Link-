// src/components/SettingsForm.jsx
import React, { useState, useEffect } from "react";

const SettingsForm = () => {
  const [userData, setUserData] = useState({
    name: "",
    email: "",
    // Add other fields as necessary
  });

  useEffect(() => {
    // Fetch user data from API and set it to state
    // Example:
    // fetchUserData().then(data => setUserData(data));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Submit updated user data to API
    // Example:
    // updateUserData(userData).then(response => {
    //   // Handle response
    // });
  };

  return (
    <form onSubmit={handleSubmit} className="settings-form">
      <div>
        <label htmlFor="name">Name:</label>
        <input
          type="text"
          id="name"
          name="name"
          value={userData.name}
          onChange={handleChange}
          required
        />
      </div>
      <div>
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="email"
          name="email"
          value={userData.email}
          onChange={handleChange}
          required
        />
      </div>
      {/* Add other fields as necessary */}
      <button type="submit">Save Changes</button>
    </form>
  );
};

export default SettingsForm;
