import React from "react";
import "../styles/button.css"; // Import CSS styles

const Button = ({
  text,
  onClick,
  type = "primary",
  size = "medium",
  disabled = false,
}) => {
  return (
    <button
      className={`btn ${type} ${size}`}
      onClick={onClick}
      disabled={disabled}
    >
      {text}
    </button>
  );
};

export default Button;
