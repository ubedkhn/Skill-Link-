import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  FileText,
  MessageSquare,
  Bell,
  Settings,
} from "lucide-react";

const Sidebar = () => {
  return (
    <div className="fixed md:w-64 w-56 h-full bg-white shadow-sm p-4 overflow-hidden">
      {/* Logo Section */}
      <svg
        className="h-8 w-auto"
        viewBox="0 0 300 100"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g transform="translate(20, 0)">
          <circle cx="30" cy="50" r="15" fill="#2563EB" />
          <circle cx="80" cy="50" r="15" fill="#1E40AF" />
          <line
            x1="45"
            y1="50"
            x2="65"
            y2="50"
            stroke="#2563EB"
            strokeWidth="4"
          />
          <text
            x="110"
            y="63"
            fontFamily="Arial"
            fontWeight="bold"
            fontSize="40"
            fill="#1F2937"
          >
            Skill<tspan fill="#2563EB">Link</tspan>
          </text>
        </g>
      </svg>

      {/* Navigation Links */}
      <nav className="mt-8 space-y-2">
        <Button variant="ghost" className="w-full justify-start">
          <LayoutDashboard className="mr-2 h-4 w-4" />
          Dashboard
        </Button>
        <Button variant="ghost" className="w-full justify-start">
          <FileText className="mr-2 h-4 w-4" />
          Projects
        </Button>
        <Button variant="ghost" className="w-full justify-start">
          <MessageSquare className="mr-2 h-4 w-4" />
          Messages
        </Button>
        <Button variant="ghost" className="w-full justify-start">
          <Bell className="mr-2 h-4 w-4" />
          Notifications
        </Button>
        <Button variant="ghost" className="w-full justify-start">
          <Settings className="mr-2 h-4 w-4" />
          Settings
        </Button>
      </nav>
    </div>
  );
};

export default Sidebar;
