import * as React from "react";
import { Create, SimpleForm, TextInput, BooleanInput } from "react-admin";

const UserCreate = (props) => (
  <Create {...props}>
    <SimpleForm>
      <TextInput source="name" />
      <TextInput source="email" />
      <BooleanInput source="isApproved" label="Approved" />
    </SimpleForm>
  </Create>
);

export default UserCreate;
