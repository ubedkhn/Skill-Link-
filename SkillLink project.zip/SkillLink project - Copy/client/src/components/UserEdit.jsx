import * as React from "react";
import { Edit, SimpleForm, TextInput, BooleanInput } from "react-admin";

const UserEdit = (props) => (
  <Edit {...props}>
    <SimpleForm>
      <TextInput source="name" />
      <TextInput source="email" />
      <BooleanInput source="isApproved" label="Approved" />
    </SimpleForm>
  </Edit>
);

export default UserEdit;
