import React from "react";
import "../styles/loader.css"; // Import CSS styles

const Loader = ({ size = "medium", color = "#007bff" }) => {
  return (
    <div className={`loader-container ${size}`}>
      <div
        className="loader"
        style={{ borderColor: `${color} transparent transparent transparent` }}
      ></div>
    </div>
  );
};

export default Loader;
