import { Button } from "@/components/ui/button";
import { Bell, User } from "lucide-react";
import "../styles/navbar.css";

const Navbar = () => {
  return (
    <header className="fixed top-0 left-0 w-full bg-white shadow-md p-4 flex justify-between items-center">
      {/* Logo */}
      <div className="flex items-center">
        <svg
          className="h-8 w-auto"
          viewBox="0 0 300 100"
          xmlns="http://www.w3.org/2000/svg"
        >
          <g transform="translate(20, 0)">
            <circle cx="30" cy="50" r="15" fill="#2563EB" />
            <circle cx="80" cy="50" r="15" fill="#1E40AF" />
            <line
              x1="45"
              y1="50"
              x2="65"
              y2="50"
              stroke="#2563EB"
              strokeWidth="4"
            />
            <text
              x="110"
              y="63"
              fontFamily="Arial"
              fontWeight="bold"
              fontSize="40"
              fill="#1F2937"
            >
              Skill<tspan fill="#2563EB">Link</tspan>
            </text>
          </g>
        </svg>
      </div>

      {/* Navbar Links */}
      <nav className="hidden md:flex space-x-6">
        <Button variant="ghost">Home</Button>
        <Button variant="ghost">Find Work</Button>
        <Button variant="ghost">Post a Job</Button>
        <Button variant="ghost">Pricing</Button>
        <Button variant="ghost">Contact</Button>
      </nav>

      {/* Notifications & User Profile */}
      <div className="flex items-center space-x-4">
        <Button variant="ghost">
          <Bell className="h-5 w-5" />
        </Button>
        <Button variant="ghost">
          <User className="h-5 w-5" />
        </Button>
      </div>
    </header>
  );
};

export default Navbar;
