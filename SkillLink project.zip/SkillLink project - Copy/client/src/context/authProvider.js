const authProvider = {
  login: ({ username, password }) => {
    // Implement your authentication logic here
    localStorage.setItem("auth", JSON.stringify({ username }));
    return Promise.resolve();
  },
  logout: () => {
    localStorage.removeItem("auth");
    return Promise.resolve();
  },
  checkAuth: () =>
    localStorage.getItem("auth") ? Promise.resolve() : Promise.reject(),
  getPermissions: () => Promise.resolve(),
};

export default authProvider;
