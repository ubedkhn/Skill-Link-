// src/pages/Settings.jsx
import "../Settings.css";
import React from "react";
import SettingsForm from "../components/SettingsForm";
import ChangePasswordForm from "../components/ChangePasswordForm";

const Settings = () => {
  return (
    <div className="settings-page">
      <h1>Account Settings</h1>
      <SettingsForm />
      <ChangePasswordForm />
    </div>
  );
};

export default Settings;
