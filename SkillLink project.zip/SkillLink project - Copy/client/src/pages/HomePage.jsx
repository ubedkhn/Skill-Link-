import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import "../styles/homePage.css";

const HomePage = () => {
  return (
    <div className="home-container">
      <Navbar />
      <main className="home-content">
        <h1>Welcome to SkillLink</h1>
        <p>Find the best freelancers and professionals for your projects.</p>
        <button className="home-btn">Get Started</button>
      </main>
      <Footer />
    </div>
  );
};

export default HomePage;
