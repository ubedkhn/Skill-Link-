import React from "react";
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import Footer from "../components/Footer";
import CheckoutForm from "../components/CheckoutForm";
import "../styles/payment.css";

// Load your publishable Stripe key.
const stripePromise = loadStripe("your-publishable-key-here");

const Payment = () => {
  return (
    <div className="payment-container">
      <Navbar />
      <div className="payment-content">
        <Sidebar />
        <main className="payment-main">
          <h1>Payment Page</h1>
          <div className="payment-form-container">
            <Elements stripe={stripePromise}>
              <CheckoutForm />
            </Elements>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default Payment;
