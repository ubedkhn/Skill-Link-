import React, { useState } from "react";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import Footer from "../components/Footer";
import { MessageBox, MessageList, Input, Button } from "react-chat-elements";
import "react-chat-elements/dist/main.css";
import "../styles/chat.css";

const Chat = () => {
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState("");

  const handleSend = () => {
    if (inputValue.trim()) {
      const newMessage = {
        position: "right",
        type: "text",
        text: inputValue,
        date: new Date(),
      };
      setMessages([...messages, newMessage]);
      setInputValue("");
    }
  };

  return (
    <div className="chat-container">
      <Navbar />
      <div className="chat-content">
        <Sidebar />
        <main className="chat-main">
          <h1>Chat System</h1>
          <div className="chat-box">
            <MessageList
              className="message-list"
              lockable={true}
              toBottomHeight={"100%"}
              dataSource={messages}
            />
            <div className="input-section">
              <Input
                placeholder="Type here..."
                multiline={false}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                rightButtons={<Button text="Send" onClick={handleSend} />}
              />
            </div>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default Chat;
