import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import Footer from "../components/Footer";
import "../styles/projectList.css";

const ProjectList = () => {
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    // Fetch projects from an API or define them statically
    const fetchProjects = async () => {
      // Example static data
      const projectData = [
        {
          id: 1,
          title: "Website Redesign",
          description: "Revamping the company website for a modern look.",
          status: "In Progress",
        },
        {
          id: 2,
          title: "Mobile App Development",
          description: "Creating a mobile app for our e-commerce platform.",
          status: "Completed",
        },
        {
          id: 3,
          title: "SEO Optimization",
          description: "Improving search engine rankings for our services.",
          status: "Not Started",
        },
      ];
      setProjects(projectData);
    };

    fetchProjects();
  }, []);

  return (
    <div className="project-list-container">
      <Navbar />
      <div className="project-list-content">
        <Sidebar />
        <main className="project-list-main">
          <h1>Project List</h1>
          <div className="project-cards">
            {projects.map((project) => (
              <div key={project.id} className="project-card">
                <h2>{project.title}</h2>
                <p>{project.description}</p>
                <p>Status: {project.status}</p>
                <button className="view-details-btn">View Details</button>
              </div>
            ))}
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default ProjectList;
