/*applying theme to admin pannel created in scr in form of  js

Then, apply this theme to your AdminPanel

- import * as React from "react";
import { Admin, Resource } from "react-admin";
import jsonServerProvider from "ra-data-json-server";
import authProvider from "../authProvider";
import UserList from "../components/UserList";
import UserEdit from "../components/UserEdit";
import UserCreate from "../components/UserCreate";
import theme from "../theme";

const dataProvider = jsonServerProvider("https://jsonplaceholder.typicode.com");

const AdminPanel = () => (
  <Admin
    dataProvider={dataProvider}
    authProvider={authProvider}
    theme={theme}
  >
    <Resource
      name="users"
      list={UserList}
      edit={UserEdit}
      create={UserCreate}
    />
  </Admin>
);

export default AdminPanel;
*/

//previous code

/* import * as React from "react";
import { Admin, Resource, ListGuesser, EditGuesser } from "react-admin";
import jsonServerProvider from "ra-data-json-server";
import authProvider from "../authProvider";
import UserList from "../components/UserList";
import UserEdit from "../components/UserEdit";
import UserCreate from "../components/UserCreate";

const dataProvider = jsonServerProvider("https://jsonplaceholder.typicode.com");

const AdminPanel = () => (
  <Admin dataProvider={dataProvider} authProvider={authProvider}>
    <Resource
      name="users"
      list={UserList}
      edit={UserEdit}
      create={UserCreate}
    />
  </Admin>
);

export default AdminPanel; */

//new code generate with theme

import * as React from "react";
import { Admin, Resource } from "react-admin";
import jsonServerProvider from "ra-data-json-server";
import authProvider from "../authProvider";
import UserList from "../components/UserList";
import UserEdit from "../components/UserEdit";
import UserCreate from "../components/UserCreate";
import theme from "../theme";

const dataProvider = jsonServerProvider("https://jsonplaceholder.typicode.com");

const AdminPanel = () => (
  <Admin dataProvider={dataProvider} authProvider={authProvider} theme={theme}>
    <Resource
      name="users"
      list={UserList}
      edit={UserEdit}
      create={UserCreate}
    />
  </Admin>
);

export default AdminPanel;
