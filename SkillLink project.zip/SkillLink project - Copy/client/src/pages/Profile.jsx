import React from "react";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import Footer from "../components/Footer";
import "../styles/profile.css";

const Profile = () => {
  return (
    <div className="profile-container">
      <Navbar />
      <div className="profile-content">
        <Sidebar />
        <main className="profile-main">
          <h1>User Profile</h1>
          <div className="profile-card">
            <img
              src="/assets/profile-placeholder.png"
              alt="Profile"
              className="profile-image"
            />
            <h2>John Doe</h2>
            <p>Email: johndoe@example.com</p>
            <p>Location: New York, USA</p>
            <p>Skills: Web Development, AI, Graphic Design</p>
            <button className="edit-profile-btn">Edit Profile</button>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default Profile;
